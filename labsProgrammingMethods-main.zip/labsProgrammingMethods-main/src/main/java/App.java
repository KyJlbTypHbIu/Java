import lombok.Data;

/**
 * @author ogbozoyan
 * @date 25.03.2023
 */
@Data
public class App {
    public static void main(String[] args) {
        System.out.print("Все сделал :)");
    }

}
